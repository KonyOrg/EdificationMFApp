ALTER TABLE `Courses`
	CHANGE `CourseDescription` `CourseName` VARCHAR(50);
