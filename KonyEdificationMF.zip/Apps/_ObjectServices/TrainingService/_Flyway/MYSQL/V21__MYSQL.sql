ALTER TABLE `Courses`
	ADD `CourseImage` VARCHAR(10);
