ALTER TABLE `Courses`
	MODIFY `CourseName` VARCHAR(20);
