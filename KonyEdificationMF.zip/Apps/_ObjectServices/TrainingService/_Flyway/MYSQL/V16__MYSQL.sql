ALTER TABLE `Courses`
	ADD `CourseDetails` VARCHAR(200);
