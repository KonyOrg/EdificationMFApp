ALTER TABLE `Modules`
	ADD `ModuleVideoURL` VARCHAR(500);
