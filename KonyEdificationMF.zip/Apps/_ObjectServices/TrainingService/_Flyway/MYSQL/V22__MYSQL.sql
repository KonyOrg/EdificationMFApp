ALTER TABLE `Courses`
	MODIFY `CourseImage` VARCHAR(30);
