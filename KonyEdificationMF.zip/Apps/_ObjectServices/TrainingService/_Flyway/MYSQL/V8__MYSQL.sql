ALTER TABLE `Courses`
	ADD `CourseDescription` VARCHAR(50);
