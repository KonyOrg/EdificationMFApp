ALTER TABLE `Courses_UserType_Mapping`
	DROP INDEX `9bda730dd013aa43b9adc1e1a117cb`;
