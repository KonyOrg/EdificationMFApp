ALTER TABLE `Courses`
	ADD `CourseDescription` VARCHAR(50) NOT NULL,
	MODIFY `CourseName` VARCHAR(20) NOT NULL;
