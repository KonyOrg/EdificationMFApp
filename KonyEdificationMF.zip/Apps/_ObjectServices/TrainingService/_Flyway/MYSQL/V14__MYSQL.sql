ALTER TABLE `Courses_UserType_Mapping`
	DROP INDEX `d7c890f2e9d7b88fe8aeace029bd73`;
